G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*
G04 #@! TF.CreationDate,2026-09-29T20:33:03+00:00*
G04 #@! TF.ProjectId,bayleaf-plate-right,6261796c-6561-4662-9d70-6c6174652d72,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-09-29 20:33:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H2*
X133050000Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X133050000Y-2450000D03*
G04 #@! TD*
G04 #@! TO.C,H7*
X4230000Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H6*
X22270000Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X2000000Y-2450000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X24750000Y-2450000D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X26450000Y-46150000D03*
G04 #@! TD*
M02*
