G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*
G04 #@! TF.CreationDate,2026-09-29T20:31:18+00:00*
G04 #@! TF.ProjectId,bayleaf-plate-left,6261796c-6561-4662-9d70-6c6174652d6c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-09-29 20:31:18*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H3*
X110150000Y-2450000D03*
G04 #@! TD*
G04 #@! TO.C,H7*
X130669999Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H6*
X112630000Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X1850000Y-89850000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X1850000Y-2450000D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X108450000Y-46150000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X132900000Y-2450000D03*
G04 #@! TD*
M02*
